ALTER TABLE `users` ADD `avatar_key` text;
